import { Request, Response } from 'express';
import Todo from '../models/Todo';

class TodoController {
  public async getTodos(req: Request, res: Response): Promise<void> {
    try {
      const todos = await Todo.find();
      res.json(todos);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }

  public async createTodo(req: Request, res: Response): Promise<void> {
    const todo = new Todo({
      task: req.body.task,
      done: req.body.done
    });

    try {
      const newTodo = await todo.save();
      res.status(201).json(newTodo);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  public async updateTodo(req: Request, res: Response): Promise<void> {
    try {
      await Todo.findByIdAndUpdate(req.params.id, req.body);
      res.json({ message: 'Task updated successfully' });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  public async deleteTodo(req: Request, res: Response): Promise<void> {
    try {
      await Todo.findByIdAndDelete(req.params.id);
      res.json({ message: 'Task deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
}

export default new TodoController();
