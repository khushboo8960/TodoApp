import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import todoRoutes from './routes/todoRoutes';

class App {
  public app: express.Application;

  constructor() {
    this.app = express();
    this.config();
    this.connectToDatabase();
    this.routes();
  }

  private config(): void {
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: false }));
  }

  private connectToDatabase(): void {
    const DB_URL = 'mongodb://localhost/todo_app';
    mongoose.connect(DB_URL, { useNewUrlParser: true, useUnifiedTopology: true });
    const db = mongoose.connection;
    db.on('error', console.error.bind(console, 'MongoDB connection error:'));
    db.once('open', () => console.log('Connected to the database'));
  }

  private routes(): void {
    this.app.use('/api/todos', todoRoutes);
  }
}

export default new App().app;
